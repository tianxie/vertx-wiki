package com.demo.skeleton.api.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 查询demo请求
 */
@Data
public class QueryDemoRequest {

    @NotEmpty
    private String name;

    private Integer pageNo = 0;

    private Integer pageSize = 10;

}
