package com.demo.skeleton.api.rpc;

import com.demo.skeleton.api.dto.DemoDTO;
import com.demo.skeleton.api.dto.GenericResultDto;
import com.demo.skeleton.api.dto.request.CreateDemoRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * 内部服务接口
 **/
@FeignClient(value = "demo-skeleton")
public interface DemoRpcApi {

    /**
     * 测试方法
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/v1.rpc/demo.test", method = RequestMethod.POST)
    GenericResultDto<DemoDTO> createDemo(@Valid @RequestBody CreateDemoRequest request);

}

