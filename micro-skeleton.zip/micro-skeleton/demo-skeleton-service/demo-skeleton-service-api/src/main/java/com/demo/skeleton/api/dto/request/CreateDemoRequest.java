package com.demo.skeleton.api.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 创建demo请求
 */
@Data
public class CreateDemoRequest {

    @NotEmpty
    private String name;

    private String description;

}
