package com.demo.skeleton.api.dto.request;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 编辑demo请求
 */
@Data
public class UpdateDemoRequest {

    /**
     * 从url path中获取
     */
    private Long id;

    @NotEmpty
    private String name;

    private String description;

}
