package com.demo.skeleton.api.constants;

/**
 * 错误信息码
 **/
public enum AppExcCodesEnum {

    // 业务自定义异常
    OPERATE_FAIL("DEMO.0001", "操作失败"),
    PARAM_IS_ERROR("DEMO.0002", "请求参数错误"),
    ;
    private String code;

    private String message;

    AppExcCodesEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

}
