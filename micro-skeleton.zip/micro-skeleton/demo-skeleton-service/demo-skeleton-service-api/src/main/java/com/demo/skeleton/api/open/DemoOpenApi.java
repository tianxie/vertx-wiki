package com.demo.skeleton.api.open;

import com.demo.skeleton.api.dto.DemoDTO;
import com.demo.skeleton.api.dto.GenericResultDto;
import com.demo.skeleton.api.dto.request.CreateDemoRequest;
import com.demo.skeleton.api.feign.config.FeignClientInterceptor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;

/**
 * 外部服务接口
 **/
@FeignClient(value = "demo-skeleton", configuration = FeignClientInterceptor.class)
public interface DemoOpenApi {

    /**
     * 测试方法
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/v1.api/demo.test", method = RequestMethod.POST)
    GenericResultDto<DemoDTO> createDemo(@Valid @RequestBody CreateDemoRequest request);

}
