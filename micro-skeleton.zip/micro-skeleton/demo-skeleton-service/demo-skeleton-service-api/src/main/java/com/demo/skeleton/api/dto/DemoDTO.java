package com.demo.skeleton.api.dto;

import lombok.Data;

import java.util.Map;

/**
 * 测试dto
 **/
@Data
public class DemoDTO {

    private Long id;
    private String name;
    private String description;
    private Map<String, Object> headDataMap;

}
