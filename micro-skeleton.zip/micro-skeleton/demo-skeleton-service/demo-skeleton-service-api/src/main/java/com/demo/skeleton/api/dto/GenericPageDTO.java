package com.demo.skeleton.api.dto;

import lombok.Data;

import java.util.List;

@Data
public class GenericPageDTO<T> {
    /**
     * 总数
     */
    private Long total;
    /**
     * 具体数据
     */
    private List<T> items;
}
