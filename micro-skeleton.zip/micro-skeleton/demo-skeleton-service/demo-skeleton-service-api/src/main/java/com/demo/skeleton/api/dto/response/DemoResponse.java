package com.demo.skeleton.api.dto.response;

import lombok.Data;

/**
 * demo响应对象
 */
@Data
public class DemoResponse {

    private String test;

}
