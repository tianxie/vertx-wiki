package com.demo.skeleton.service.impl;

import com.demo.skeleton.DemoApplication;
import com.demo.skeleton.model.dto.CreateDemoDto;
import com.demo.skeleton.model.dto.DemoQueryDto;
import com.demo.skeleton.model.dto.UpdateDemoDto;
import com.demo.skeleton.api.dto.DemoDTO;
import com.demo.skeleton.api.dto.GenericPageDTO;
import com.demo.skeleton.exception.AppBizException;
import com.demo.skeleton.model.SessionModel;
import com.demo.skeleton.service.DemoService;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 */
@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = DemoApplication.class)
public class DemoServiceImplTest {

    private static final Long userId = 12L;

    private static final Long deptId = 5L;

    private SessionModel session;

    @Autowired
    DemoService demoService;

    @Before
    public void init(){
        //初始化session
        session = new SessionModel();
        session.setUserId(userId);
        session.setDeptId(deptId);
    }

    @After
    public void end(){
        log.info("end");
    }

    @Test
    public void select() {
        DemoQueryDto query = new DemoQueryDto();
        query.setName("demo");
        try{
            GenericPageDTO<DemoDTO> page = demoService.select(query, 0, 10, session);
            log.info("result: {}", page);
        }catch (AppBizException e){
            e.printStackTrace();
        }
    }

    @Test
    public void create() {
        CreateDemoDto demo = new CreateDemoDto();
        demo.setName("demo" + System.currentTimeMillis());
        demo.setDescription("add");
        try{
            DemoDTO dto = demoService.create(demo, session);
            log.info("result: {}", dto);
        }catch (AppBizException e){
            e.printStackTrace();
        }
    }

    @Test
    public void update() {
        UpdateDemoDto demo = new UpdateDemoDto();
        demo.setId(1L);
        demo.setName("demo" + System.currentTimeMillis());
        demo.setDescription("edit");
        try{
            DemoDTO dto = demoService.update(demo, session);
            log.info("result: {}", dto);
        }catch (AppBizException e){
            e.printStackTrace();
        }
    }

    @Test
    public void get() {
        try{
            DemoDTO dto = demoService.get(1L, session);
            log.info("result: {}", dto);
        }catch (AppBizException e){
            e.printStackTrace();
        }
    }

    @Test
    public void delete() {
        try{
            Integer result = demoService.delete(2L, session);
            log.info("result: {}", result);
        }catch (AppBizException e){
            e.printStackTrace();
        }
    }

}