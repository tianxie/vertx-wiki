package com.demo.skeleton.mapper;

import com.demo.skeleton.model.domain.Demo;
import com.demo.skeleton.model.dto.DemoQueryDto;
import com.demo.skeleton.mapper.base.DemoMySqlMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * demo表mapper
 **/
@Mapper
public interface DemoMapper extends DemoMySqlMapper<Demo> {

    /**
     * 查询demo
     * @param query
     * @return
     */
    List<Demo> selectByQuery(@Param("query") DemoQueryDto query);

}