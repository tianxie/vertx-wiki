package com.demo.skeleton.controller.open;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.demo.skeleton.api.dto.DemoDTO;
import com.demo.skeleton.api.dto.GenericResultDto;
import com.demo.skeleton.api.dto.request.CreateDemoRequest;
import com.demo.skeleton.api.open.DemoOpenApi;
import com.demo.skeleton.service.DemoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * 外部服务接口
 **/
@RestController
@Validated
@Slf4j
public class DemoOpenController implements DemoOpenApi {

    @Autowired
    private HttpServletRequest httpRequest;

    @Autowired
    DemoService demoService;

    @Override
    @HystrixCommand(commandProperties = {
            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "1000"),
            @HystrixProperty(name = "execution.timeout.enabled", value = "true")
    }, fallbackMethod = "createDemoFallback")
    public GenericResultDto<DemoDTO> createDemo(@Valid @RequestBody CreateDemoRequest request) {
        log.info("i am in createDemo!");
        //throw new RuntimeException("a runtime exception happened");

        Map<String, Object> dataMap = new HashMap<>();
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        if (requestAttributes == null) {
            log.warn("requestAttributes CANT be obtained.");
            return null;
        }

        HttpServletRequest localRequest = ((ServletRequestAttributes) requestAttributes).getRequest();
        Enumeration<String> headerNames = localRequest.getHeaderNames();
        if (headerNames != null) {
            while (headerNames.hasMoreElements()) {
                String name = headerNames.nextElement();
                Enumeration<String> values = localRequest.getHeaders(name);
                while (values.hasMoreElements()) {
                    String value = values.nextElement();
                    dataMap.put(name, value);
                }
            }
        }
        DemoDTO demoDTO = new DemoDTO();
        demoDTO.setName(request.getName());
        demoDTO.setHeadDataMap(dataMap);
        return GenericResultDto.ok(demoDTO);
    }

    /**
     * 降级方法
     *
     * @return
     */
    protected GenericResultDto<DemoDTO> createDemoFallback(@Valid @RequestBody CreateDemoRequest request) {
        DemoDTO demoDTO = new DemoDTO();
        demoDTO.setName("fallback call");
        GenericResultDto<DemoDTO> response = GenericResultDto.ok(demoDTO);
        return response;
    }

}
