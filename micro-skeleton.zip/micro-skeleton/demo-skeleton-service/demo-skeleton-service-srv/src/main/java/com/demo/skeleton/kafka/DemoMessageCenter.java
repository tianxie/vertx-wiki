package com.demo.skeleton.kafka;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

public interface DemoMessageCenter {

    String OUTPUT_DEMO_TEST = "output_demo_test";

    String INPUT_DEMO_TEST = "input_demo_test";

    /**
     * 输出
     * @return
     */
    @Output(DemoMessageCenter.OUTPUT_DEMO_TEST)
    MessageChannel outputDemoTest();

    /**
     * 输入
     * @return
     */
    @Input(DemoMessageCenter.INPUT_DEMO_TEST)
	SubscribableChannel inputDemoTest();

}
