package com.demo.skeleton.model.dto;

import com.demo.skeleton.api.dto.request.QueryDemoRequest;
import lombok.Data;

/**
 * 查询demo
 */
@Data
public class DemoQueryDto {

    private String name;

    public static DemoQueryDto from(QueryDemoRequest request) {
        DemoQueryDto query = new DemoQueryDto();
        query.setName(request.getName());
        return query;
    }

}
