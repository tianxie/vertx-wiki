package com.demo.skeleton.model.dto;

import com.demo.skeleton.api.dto.request.UpdateDemoRequest;
import lombok.Data;

/**
 * 编辑demo
 */
@Data
public class UpdateDemoDto {

    private Long id;
    private String name;
    private String description;

    public static UpdateDemoDto from(UpdateDemoRequest request) {
        UpdateDemoDto dto = new UpdateDemoDto();
        dto.setId(request.getId());
        dto.setName(request.getName());
        dto.setDescription(request.getDescription());
        return dto;
    }

}
