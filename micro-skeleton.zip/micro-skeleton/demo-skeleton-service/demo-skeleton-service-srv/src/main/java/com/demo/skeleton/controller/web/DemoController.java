package com.demo.skeleton.controller.web;

import com.demo.skeleton.api.dto.DemoDTO;
import com.demo.skeleton.api.dto.GenericPageDTO;
import com.demo.skeleton.api.dto.GenericResultDto;
import com.demo.skeleton.api.dto.request.CreateDemoRequest;
import com.demo.skeleton.api.dto.request.QueryDemoRequest;
import com.demo.skeleton.api.dto.request.UpdateDemoRequest;
import com.demo.skeleton.exception.AppBizException;
import com.demo.skeleton.model.dto.CreateDemoDto;
import com.demo.skeleton.model.dto.DemoQueryDto;
import com.demo.skeleton.model.dto.UpdateDemoDto;
import com.demo.skeleton.model.SessionModel;
import com.demo.skeleton.service.DemoService;
import com.demo.skeleton.utils.SessionUserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

/**
 * 后台接口
 **/
@RestController
@Validated
public class DemoController {

    @Autowired
    HttpServletRequest httpRequest;

    @Resource
    HttpServletResponse httpResponse;

    @Autowired
    DemoService demoService;

    @GetMapping("/v1/demo.page")
    public GenericResultDto<GenericPageDTO<DemoDTO>> queryDemo(@Valid QueryDemoRequest request) {
        GenericResultDto<GenericPageDTO<DemoDTO>> response ;
        try {
            //从http请求中获取session信息
            SessionModel session = SessionUserUtils.getSession(httpRequest);
            GenericPageDTO<DemoDTO> page = demoService.select(DemoQueryDto.from(request), request.getPageNo(), request.getPageSize(), session);
            response = GenericResultDto.ok(page);
        } catch (AppBizException e) {
            response = GenericResultDto.fail(e.getCode(), e.getMessage());
        }
        return response;

    }

    @PostMapping("/v1/demo")
    public GenericResultDto<DemoDTO> createDemo(@Valid @RequestBody CreateDemoRequest request) {
        GenericResultDto<DemoDTO> response ;
        try {
            //从http请求中获取session信息
            SessionModel session = SessionUserUtils.getSession(httpRequest);
            DemoDTO dto = demoService.create(CreateDemoDto.from(request), session);
            response = GenericResultDto.ok(dto);
        } catch (AppBizException e) {
            response = GenericResultDto.fail(e.getCode(), e.getMessage());
        }
        return response;
    }

    @PutMapping("/v1/demo/{id}")
    public GenericResultDto<DemoDTO> updateDemo(@PathVariable Long id,
                                               @Valid @RequestBody UpdateDemoRequest request) {
        request.setId(id);
        GenericResultDto<DemoDTO> response ;
        try {
            //从http请求中获取session信息
            SessionModel session = SessionUserUtils.getSession(httpRequest);
            DemoDTO dto = demoService.update(UpdateDemoDto.from(request), session);
            response = GenericResultDto.ok(dto);
        } catch (AppBizException e) {
            response = GenericResultDto.fail(e.getCode(), e.getMessage());
        }
        return response;
    }

    /**
     * 获取设备的字典配置
     * @return
     */
    @GetMapping("/v1/demo/{id}")
    public GenericResultDto<DemoDTO> getDemo(@PathVariable Long id) {
        GenericResultDto<DemoDTO> response ;
        try {
            //从http请求中获取session信息
            SessionModel session = SessionUserUtils.getSession(httpRequest);
            DemoDTO dto = demoService.get(id, session);
            response = GenericResultDto.ok(dto);
        } catch (AppBizException e) {
            response = GenericResultDto.fail(e.getCode(), e.getMessage());
        }
        return response;
    }

    @DeleteMapping("/v1/demo/{id}")
    public GenericResultDto<String> deleteDemo(@PathVariable Long id) {
        GenericResultDto<String> response ;
        try {
            //从http请求中获取session信息
            SessionModel session = SessionUserUtils.getSession(httpRequest);
            demoService.delete(id, session);
            response = GenericResultDto.ok();
        } catch (AppBizException e) {
            response = GenericResultDto.fail(e.getCode(), e.getMessage());
        }
        return response;
    }

    @PostMapping("/v1/demo/kafka")
    public GenericResultDto<String> testKafka(@NotEmpty String payload) {
        GenericResultDto<String> result;
        try {
            demoService.testKafka(payload);
            //返回
            result = GenericResultDto.ok();
        } catch (AppBizException e) {
            result = GenericResultDto.fail(e.getCode(), e.getMessage());
        }
        return result;
    }

}

