package com.demo.skeleton.exception;


import com.demo.skeleton.api.constants.AppExcCodesEnum;
import com.demo.skeleton.api.dto.ResultDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;


/**
 * 全局的的异常拦截器
 **/
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 参数非法异常.
     *
     * @param e the e
     * @return the wrapper
     */
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResultDto illegalArgumentException(IllegalArgumentException e) {
        log.error("参数非法异常={}", e.getMessage(), e);
        return ResultDto.fail(AppExcCodesEnum.OPERATE_FAIL.getCode(), e.getMessage());
    }

    /**
     * 业务异常.
     *
     * @param e the e
     * @return the wrapper
     */
    @ExceptionHandler(AppBizException.class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResultDto businessException(AppBizException e) {
        log.error("业务异常={}", e.getMessage(), e);
        return ResultDto.fail(e.getCode(), e.getMessage());
    }

    /**
     * 全局异常.
     *
     * @param e the e
     * @return the wrapper
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResultDto exception(Exception e) {
        log.info("保存全局异常信息 ex={}", e.getMessage(), e);
        return ResultDto.fail(AppExcCodesEnum.OPERATE_FAIL.getCode(), e.getMessage());
    }
}
