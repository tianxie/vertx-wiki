package com.demo.skeleton.kafka;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@EnableBinding(DemoMessageCenter.class)
public class DemoMessageConsumer {

    @StreamListener(DemoMessageCenter.INPUT_DEMO_TEST)
    public void inputDemoTest(Message<String> message) {
        log.info("inputDemoTest receive: " + message.getPayload());
    }

}
