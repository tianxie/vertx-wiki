package com.demo.skeleton.model.domain;

import lombok.Data;

import java.util.Date;
import javax.persistence.*;

/**
 * demo表po对象
 **/
@Data
@Table(name = "demo")
public class Demo {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(generator = "JDBC")
    private Long id;

    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String description;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @Column(name = "update_time")
    private Date updateTime;

}