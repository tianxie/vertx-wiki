package com.demo.skeleton.utils;

import com.google.gson.Gson;
import com.demo.skeleton.model.SessionModel;
import org.apache.commons.lang3.StringUtils;
import javax.servlet.http.HttpServletRequest;

public class SessionUserUtils {
    private static Gson gson = new Gson();
    public static final String SESSION_KEY = "session";

    public SessionUserUtils() {
    }

    public static SessionModel getSession(HttpServletRequest request) {
        String sessStr = request.getHeader("session");
        if (StringUtils.isNotBlank(sessStr)) {
            SessionModel session = (SessionModel) gson.fromJson(sessStr, SessionModel.class);
            return session;
        } else {
            return null;
        }
    }

    public static Long getUserId(HttpServletRequest request) {
        SessionModel session = getSession(request);
        return session == null ? 0L : session.getUserId();
    }

    public static Long getCompanyId(HttpServletRequest request) {
        SessionModel session = getSession(request);
        return session == null ? 0L : session.getCompanyId();
    }

    public static Long getDeptId(HttpServletRequest request) {
        SessionModel session = getSession(request);
        return session == null ? 0L : session.getDeptId();
    }
}
