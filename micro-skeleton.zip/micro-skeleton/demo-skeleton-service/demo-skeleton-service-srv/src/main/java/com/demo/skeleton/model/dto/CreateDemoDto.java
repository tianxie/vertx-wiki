package com.demo.skeleton.model.dto;

import com.demo.skeleton.api.dto.request.CreateDemoRequest;
import lombok.Data;

/**
 * 创建demo
 */
@Data
public class CreateDemoDto {

    private String name;
    private String description;

    public static CreateDemoDto from(CreateDemoRequest request) {
        CreateDemoDto dto = new CreateDemoDto();
        dto.setName(request.getName());
        dto.setDescription(request.getDescription());
        return dto;
    }

}
