package com.demo.skeleton.service;

import com.demo.skeleton.api.dto.DemoDTO;
import com.demo.skeleton.api.dto.GenericPageDTO;
import com.demo.skeleton.exception.AppBizException;
import com.demo.skeleton.model.SessionModel;
import com.demo.skeleton.model.dto.CreateDemoDto;
import com.demo.skeleton.model.dto.DemoQueryDto;
import com.demo.skeleton.model.dto.UpdateDemoDto;

/**
 * demo服务
 */
public interface DemoService {

    /**
     * 查询demo
     * @param query
     * @param pageNo
     * @param pageSize
     * @param session
     * @return
     * @throws AppBizException
     */
    GenericPageDTO<DemoDTO> select(DemoQueryDto query,
                                   Integer pageNo,
                                   Integer pageSize,
                                   SessionModel session) throws AppBizException;

    /**
     * 创建demo
     * @param dto
     * @param session
     * @return
     * @throws AppBizException
     */
    DemoDTO create(CreateDemoDto dto, SessionModel session) throws AppBizException;

    /**
     * 编辑demo
     * @param dto
     * @param session
     * @return
     * @throws AppBizException
     */
    DemoDTO update(UpdateDemoDto dto, SessionModel session) throws AppBizException;

    /**
     * 查询demo
     * @param id
     * @param session
     * @return
     * @throws AppBizException
     */
    DemoDTO get(Long id, SessionModel session) throws AppBizException;

    /**
     * 删除demo
     * @param id
     * @param session
     * @return
     * @throws AppBizException
     */
    Integer delete(Long id, SessionModel session) throws AppBizException;

    /**
     * 测试kafka
     * @param payload
     * @throws AppBizException
     */
    void testKafka(String payload) throws AppBizException;

}
