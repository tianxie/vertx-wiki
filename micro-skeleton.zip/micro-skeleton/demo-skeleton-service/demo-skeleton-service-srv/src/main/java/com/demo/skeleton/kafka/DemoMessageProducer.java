package com.demo.skeleton.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service
@EnableBinding(DemoMessageCenter.class)
public class DemoMessageProducer {

    @Autowired
    private DemoMessageCenter demoMessageCenter;

    public void outputDemoTest(Message<?> message){
        demoMessageCenter.outputDemoTest().send(message);
    }

}
