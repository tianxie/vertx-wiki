package com.demo.skeleton.service.impl;

import com.demo.skeleton.kafka.DemoMessageProducer;
import com.demo.skeleton.model.domain.Demo;
import com.demo.skeleton.model.dto.CreateDemoDto;
import com.demo.skeleton.model.dto.DemoQueryDto;
import com.demo.skeleton.model.dto.UpdateDemoDto;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.demo.skeleton.api.constants.AppExcCodesEnum;
import com.demo.skeleton.api.dto.DemoDTO;
import com.demo.skeleton.api.dto.GenericPageDTO;
import com.demo.skeleton.exception.AppBizException;
import com.demo.skeleton.mapper.DemoMapper;
import com.demo.skeleton.model.SessionModel;
import com.demo.skeleton.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * demo服务
 */
@Service
public class DemoServiceImpl implements DemoService {

    @Autowired
    DemoMapper demoMapper;

    @Autowired
    DemoMessageProducer messageProducer;

    /**
     * 配置断路器线程池相关参数及
     *//*
    public DemoServiceImpl() {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("DemoGroupKey"))
                .andCommandKey(HystrixCommandKey.Factory.asKey("DemoCommandKey"))
                .andThreadPoolKey(HystrixThreadPoolKey.Factory.asKey("DemoThreadPoolKey"))
                .andCommandPropertiesDefaults(HystrixCommandProperties.Setter()
                        .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.THREAD)
                        //允许执行的最大并发数
                        .withExecutionIsolationSemaphoreMaxConcurrentRequests(30)
                        //请求超时
                        .withExecutionTimeoutInMilliseconds(300))
                .andThreadPoolPropertiesDefaults(HystrixThreadPoolProperties.Setter()
                        //允许线程池自动从coreSize扩容到maximumSize
                        .withAllowMaximumSizeToDivergeFromCoreSize(true)
                        //default 10，默认线程池大小
                        .withCoreSize(10)
                        //最大线程数
                        .withMaximumSize(30)
                        //空闲线程存活时间1分钟，超时后线程池数量自动恢复到coreSize大小
                        .withKeepAliveTimeMinutes(1)
                        //default 5，没有被线程池执行的请求会放到队列中等待线程，如果队列已满，新来的请求会被降级被拒
                        .withQueueSizeRejectionThreshold(10)
                        //withQueueSizeRejectionThreshold和withMaxQueueSize比较，queueSize取较小值
                        .withMaxQueueSize(10)));
    }*/


    private DemoDTO demo2dto(Demo demo){
        DemoDTO dto = new DemoDTO();
        dto.setId(demo.getId());
        dto.setName(demo.getName());
        dto.setDescription(demo.getDescription());
        return dto;
    }

    @Override
    public GenericPageDTO<DemoDTO> select(DemoQueryDto query,
                                          Integer pageNo,
                                          Integer pageSize,
                                          SessionModel session) throws AppBizException {
        GenericPageDTO<DemoDTO> result = new GenericPageDTO<>();
        //分页查询
        PageHelper.startPage(pageNo, pageSize);
        List<Demo> list = demoMapper.selectByQuery(query);
        PageInfo<Demo> pageInfo = new PageInfo<>(list);
        List<DemoDTO> dtoList = list.stream().map(demo -> demo2dto(demo)).collect(Collectors.toList());
        result.setTotal(pageInfo.getTotal());
        result.setItems(dtoList);
        return result;
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public DemoDTO create(CreateDemoDto dto, SessionModel session) throws AppBizException {
        Demo demo = new Demo();
        demo.setName(dto.getName());
        demo.setDescription(dto.getDescription());
        demo.setCreateTime(new Date());
        demoMapper.insert(demo);
        return demo2dto(demo);
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public DemoDTO update(UpdateDemoDto dto, SessionModel session) throws AppBizException {
        Demo demo = demoMapper.selectByPrimaryKey(dto.getId());
        if(demo == null){
            throw new AppBizException(AppExcCodesEnum.PARAM_IS_ERROR);
        }
        demo.setName(dto.getName());
        demo.setDescription(dto.getDescription());
        demo.setUpdateTime(new Date());
        demoMapper.updateByPrimaryKey(demo);
        return demo2dto(demo);
    }

    @Override
    public DemoDTO get(Long id, SessionModel session) throws AppBizException {
        Demo demo = demoMapper.selectByPrimaryKey(id);
        if(demo == null){
            throw new AppBizException(AppExcCodesEnum.PARAM_IS_ERROR);
        }
        DemoDTO result = new DemoDTO();
        result.setId(demo.getId());
        result.setName(demo.getName());
        result.setDescription(demo.getDescription());
        return result;
    }

    @Override
    public Integer delete(Long id, SessionModel session) throws AppBizException {
        Demo demo = demoMapper.selectByPrimaryKey(id);
        if(demo == null){
            throw new AppBizException(AppExcCodesEnum.PARAM_IS_ERROR);
        }
        return demoMapper.deleteByPrimaryKey(id);
    }

    @Override
    public void testKafka(String payload) throws AppBizException {
        messageProducer.outputDemoTest(MessageBuilder.withPayload(payload).build());
    }

    /*@Override
    protected DemoDTO run() throws Exception {
        return null;
    }*/
}
