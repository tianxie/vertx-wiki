# 微服务脚手架项目说明

## 项目结构说明

    ├─demo-skeleton-service-api
    │  ├─src
    │     └─main
    │         └─java
    │             └─com
    │                 └─demo
    │                     └─skeleton
    │                         └─api
    │                             ├─constants 常量定义
    │                             ├─dto 中间dto对象
    │                             │  ├─request 请求dto对象
    │                             │  └─response 响应dto对象
    │                             ├─open 通过网关对外暴露api
    |                             ├─feign 
    |                             |  └─config feign配置  
    │                             └─rpc 内部使用api
    └─demo-skeleton-service-srv
        ├─src
        │  ├─main
        │  │  ├─java
        │  │  │  └─com
        │  │  │      └─demo
        │  │  │          └─skeleton
        │  │  │              ├─config 配置文件定义
        │  │  │              ├─controller 接口实现包
        │  │  │              │  ├─open 对外暴露接口（外部应用或项目）
        │  │  │              │  ├─rpc 内部使用接口（项目内部其他服务使用）
        │  │  │              │  └─web 后台web接口
        │  │  │              ├─exception 
        │  │  │              ├─kafka 消息实现
        │  │  │              ├─interceptor 拦截器实现
        │  │  │              ├─mapper mybatis映射
        │  │  │              │  └─base
        │  │  │              ├─model 
        │  │  │              │  ├─domain 数据库映射模型
        │  │  │              │  └─dto 内部用dto
        │  │  │              ├─service service接口定义
        │  │  │              │  └─impl service接口实现
        │  │  │              └─utils 工具包
        │  │  └─resources 
        │  │      ├─mapper mybatis插件自动生成mapper xml
        │  │      └─sql sql脚本
        │  └─test 
        │     
        └─target 打包文件目录
            

## pom依赖关系


    spring-boot-starter-parent 
                        └─demo-skeleton-service 业务项目pom
                                                    ├─demo-skeleton-service-api.jar 项目对外暴露的api jar，单纯后台项目无需此module。
                                                    └─demo-skeleton-service-srv 依赖demo-skeleton-service-api.jar。

                                                                       
## 项目引入通用基础依赖说明

+ demo-skeleton-service-api 接口api依赖包
+ spring-cloud-starter-netflix-eureka-client 注册中心eureka客户端
+ spring-cloud-starter-netflix-hystrix spring cloud断路器（服务降级）
+ druid-spring-boot-starter mysql数据库连接池
+ mapper-spring-boot-starter mybatis依赖
+ pagehelper-spring-boot-starter mybastis分页查询组件
+ spring-cloud-starter-stream-kafka spring cloud kafka消息组件
+ spring-boot-starter-data-redis redis组件
+ lombok 组件
+ spring-boot-admin-starter-client springBoot admin监控客户端

## 项目异常处理流程
* AppExcCodesEnum 异常信息枚举，包含异常code和message，定义业务异常
* GenericResultDto 封装rest接口返回对象，定义success和failure常量
* GenericPageDTO 封装rest列表查询接口返回数据通用对象，和GenericResultDto结合使用
* AppBizRuntimeException 业务自定义runtime exception，运行期异常可以统一抛出这个对象，交GlobalExceptionHandler统一处理，异常类型来自AppExcCodesEnum
* GlobalExceptionHandler 全局异常处理handler，处理业务抛出异常

**建议业务代码中不处理异常，都向上抛出，由GlobalExceptionHandler处理**

## feign调用方法（微服务调用）
* pom导入依赖api
* 注入关联feignClient实例
* 使用feignClient实例完成对微服务的调用
* 具体实例可参考 TestController

## hystrix断路器用法（服务熔断，降级，限流）
* 默认熔断阈值为失败超过50%，默认采样周期为10秒，可通过配置文件自定义配置
* 熔断后如果指定了fallback方法，并且配置降级允许，会执行指定降级方法，fallback并发达到阈值会进行快速失败。
* 熔断后一个时间窗口后（默认5秒），会放行一次服务请求进行服务验证，如果服务恢复正常，则断路器关闭，否则依然保持打开状态。
* hystrix默认采用线程隔离模型，自定义配置服务线程池大小及队列大小，资源隔离保护之间互不影响，线程池和队列耗尽则执行快速失败策略（fast-fail)。
* 具体实例可参考 DemoOpenController实现

## api协议结构
#### 基本json结构
`{
     	"code": "200",
     	"msg": "操作成功!",
     	"data": {
     		"param1": "value1"
     	}
     }`
     
#### 列表json结构
`{
 	"code": "200",
 	"msg": "操作成功!",
 	"data": {
 		"total": 999,
 		"items": [{
 			"param1": "value1",
 			"param2": "value2"
 		}]
 	}
 }`

## 使用方法
    1.clone项目到本地
    2.修改项目名称，artifact名称，服务名称，项目包名
    3.添加需要的第三方业务依赖
    4.业务自定义开发
    5.服务的路由监控等通用服务，可以依赖中台架构室提供的研发集成平台来支持。
