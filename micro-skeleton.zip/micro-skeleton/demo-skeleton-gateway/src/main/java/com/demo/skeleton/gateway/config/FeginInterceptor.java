package com.demo.skeleton.gateway.config;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


import feign.RequestInterceptor;
import feign.RequestTemplate;

@Configuration
public class FeginInterceptor implements RequestInterceptor {
    String AUTH_HEAD_NAME = "Authorization";

    @Override
    public void apply(RequestTemplate requestTemplate) {
        String tokenValue = getHeaders(getHttpServletRequest());
        requestTemplate.header(AUTH_HEAD_NAME, tokenValue);
    }

    private HttpServletRequest getHttpServletRequest() {
        try {
            return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String getHeaders(HttpServletRequest request) {
        Enumeration<String> enumeration = request.getHeaderNames();
        while (enumeration.hasMoreElements()) {
            String key = enumeration.nextElement();
            if (key.toUpperCase().equals(AUTH_HEAD_NAME.toUpperCase())) {
                return request.getHeader(key);
            }
        }
        return null;
    }


}
