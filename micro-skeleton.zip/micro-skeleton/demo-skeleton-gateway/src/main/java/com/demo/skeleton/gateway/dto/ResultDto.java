package com.demo.skeleton.gateway.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResultDto {
    private static final String SUCCESS_CODE = "0000";
    private static final String FAILURE_CODE = "9999";

    /**
     * 返回码
     */
    private String code;
    /**
     * 返回消息
     */
    private String msg;
    /**
     * 返回数据
     */
    private Object data;

    @JsonIgnore
    public boolean isSuccess() {
        return SUCCESS_CODE.equals(this.code);
    }

    @JsonIgnore
    public boolean isFailure() {
        return !isSuccess();
    }

    public static ResultDto ok(Object data) {
        ResultDto resultDto = new ResultDto();
        resultDto.setCode(SUCCESS_CODE);
        resultDto.setData(data);
        return resultDto;
    }

    public static ResultDto ok() {
        ResultDto resultDto = new ResultDto();
        resultDto.setCode(SUCCESS_CODE);
        return resultDto;
    }


    public static ResultDto fail(String code, String msg) {
        ResultDto resultDto = new ResultDto();
        resultDto.setCode(code);
        resultDto.setMsg(msg);
        return resultDto;
    }
}
