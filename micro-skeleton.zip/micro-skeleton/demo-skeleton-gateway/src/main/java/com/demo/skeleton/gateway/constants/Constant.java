package com.demo.skeleton.gateway.constants;

public class Constant {

    /**
     * 用户微服务白名单路径
     */
    public final static String USER_SERVICE_WHITELIST = "/user/v1/auth/";

    public final static String DEVICE_XLSX_WHITELIST = "/device/resource";

    public final static String EXCEL_TEMPLATE_WHITELIST = "/resource";
    /**
     * 基础微服务白名单路径
     */
    public final static String BASE_SERVICE_WHITELIST = "/base/";
    /**
     * 用户微服务路径
     */
    public final static String USER_SERVICE_PATH = "/user/";
    /**
     * JWT token 秘钥
     */
    public final static String JWT_SECRET_KEY = "webapp";

    /**
     * JWT token 用户id获取key
     */
    public final static String JWT_USERID_KEY = "userId";

    /**
     * JWT token 公司id获取key
     */
    public final static String JWT_COMPANYID_KEY = "companyId";

    /**
     * JWT token 部门id获取key
     */
    public final static String JWT_DEPTID_KEY = "deptId";

    /**
     * API接口头部session key
     */
    public final static String RESTAPI_HEADER_SESSION_KEY = "session";


}