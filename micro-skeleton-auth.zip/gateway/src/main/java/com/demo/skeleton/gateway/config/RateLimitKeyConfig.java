package com.demo.skeleton.gateway.config;

import com.demo.skeleton.gateway.utils.IpUtils;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.RateLimitKeyGenerator;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.RateLimitUtils;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.properties.RateLimitProperties;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.repository.DefaultRateLimiterErrorHandler;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.repository.RateLimiterErrorHandler;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.support.DefaultRateLimitKeyGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.netflix.zuul.filters.Route;
import org.springframework.context.annotation.Bean;

import javax.servlet.http.HttpServletRequest;

/**
 * zuul限流扩展--策略生成的key
 * 因为默认的策略key 在循环policy-list 的配置时会将当前的url对应的策略 policy 覆盖掉
 */

//@Configuration
public class RateLimitKeyConfig {

    private static final Logger log = LoggerFactory.getLogger(RateLimitKeyConfig.class);

    @Bean
    public RateLimitKeyGenerator ratelimitKeyGenerator(RateLimitProperties properties, RateLimitUtils rateLimitUtils) {

        return new DefaultRateLimitKeyGenerator(properties, rateLimitUtils) {

            @Override
            public String key(HttpServletRequest request, Route route, RateLimitProperties.Policy policy) {
                String key = super.key(request, route, policy);
                key = key + ":" + request.getMethod() + ":" + IpUtils.getIpAddr(request);
                log.info("key:" + key);
                return key;
            }
        };
    }

    /**
     * handle the errors differently
     *
     * @return
     */
    @Bean
    public RateLimiterErrorHandler rateLimitErrorHandler() {
        return new DefaultRateLimiterErrorHandler() {
            @Override
            public void handleSaveError(String key, Exception e) {
                log.error("handleSaveError: " + key);
            }

            @Override
            public void handleFetchError(String key, Exception e) {
                log.error("handleFetchError: " + key);
            }

            @Override
            public void handleError(String msg, Exception e) {
                log.error("handleError: " + msg);
            }
        };
    }


}
