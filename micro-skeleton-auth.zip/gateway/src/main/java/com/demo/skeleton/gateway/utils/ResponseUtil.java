package com.demo.skeleton.gateway.utils;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.netflix.zuul.context.RequestContext;

public class ResponseUtil {

    public static void writeResponseJson(RequestContext context, Map<String, String> map) {
        HttpServletResponse response = context.getResponse();
        Gson GSON = new Gson();
        PrintWriter printWriter = null;
        response.setContentType("application/json; charset=utf-8");
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
        printWriter.write(GSON.toJson(map));
        printWriter.close();
        try {
            response.flushBuffer();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
