package com.demo.skeleton.gateway.filter;

import java.util.HashMap;
import java.util.Map;

import com.demo.skeleton.gateway.utils.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.support.RateLimitExceededException;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

@Component
public class ErrorFilter extends ZuulFilter {

    private static final Logger logger = LoggerFactory.getLogger(ErrorFilter.class);

    @Override
    public String filterType() {
        return "error";
    }

    @Override
    public int filterOrder() {
        return -1;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() {
        try {
            RequestContext context = RequestContext.getCurrentContext();
            String msg = this.findZuulException(context.getThrowable());

            Map<String, String> map = new HashMap<>(3);
            map.put("code", "GW.500");
            map.put("msg", msg);
            ResponseUtil.writeResponseJson(context, map);
        } catch (Exception var5) {
            ReflectionUtils.rethrowRuntimeException(var5);
        }

        return null;
    }

    private String findZuulException(Throwable throwable) {
        logger.error("进入ErrorFilter异常拦截", throwable);
        if (RateLimitExceededException.class.isInstance(throwable.getCause())) {
            return "接口访问频次过高";
        }
        return "服务异常";
    }

}