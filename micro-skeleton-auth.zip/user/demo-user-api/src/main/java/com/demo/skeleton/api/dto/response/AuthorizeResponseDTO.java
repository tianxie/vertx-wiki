package com.demo.skeleton.api.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

public class AuthorizeResponseDTO {
    private Boolean firstLogin;
    private Boolean initPwd;
    private String idToken;
    private Set<Long> companies;

    public Boolean getFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(Boolean firstLogin) {
        this.firstLogin = firstLogin;
    }

    public Boolean getInitPwd() {
        return initPwd;
    }

    public void setInitPwd(Boolean initPwd) {
        this.initPwd = initPwd;
    }

    public Set<Long> getCompanies() {
        return companies;
    }

    public void setCompanies(Set<Long> companies) {
        this.companies = companies;
    }

    @JsonProperty("id_token")
    public String getIdToken() {
        return idToken;
    }

    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }

}
