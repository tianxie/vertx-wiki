package com.demo.skeleton.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenericResultDto<T> {
    private static final String SUCCESS_CODE = "0000";
    private static final String FAILURE_CODE = "9999";
    private static final String SUCCESS_MSG = "操作成功!";

    /**
     * 返回码
     */
    private String code;
    /**
     * 返回消息
     */
    private String msg;
    /**
     * 返回数据
     */
    private T data;

    @JsonIgnore
    public boolean isSuccess() {
        return SUCCESS_CODE.equals(this.code);
    }

    @JsonIgnore
    public boolean isFailure() {
        return !isSuccess();
    }


    public static <T> GenericResultDto<T> ok(T data) {
        GenericResultDto<T> resultDto = new GenericResultDto<>();
        resultDto.setCode(SUCCESS_CODE);
        resultDto.setMsg(SUCCESS_MSG);
        resultDto.setData(data);
        return resultDto;
    }

    public static GenericResultDto ok() {
        GenericResultDto resultDto = new GenericResultDto();
        resultDto.setCode(SUCCESS_CODE);
        resultDto.setMsg(SUCCESS_MSG);
        return resultDto;
    }


    public static <T> GenericResultDto<T> fail(String code, String msg) {
        GenericResultDto<T> resultDto = new GenericResultDto<>();
        resultDto.setCode(code);
        resultDto.setMsg(msg);
        return resultDto;
    }
}
