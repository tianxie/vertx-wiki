package com.demo.skeleton.api;

import com.demo.skeleton.api.dto.GenericResultDto;
import com.demo.skeleton.api.dto.ManagedUserDTO;
import com.demo.skeleton.api.dto.ResultDto;
import com.demo.skeleton.api.dto.request.LoginVM;
import com.demo.skeleton.api.dto.response.AuthorizeResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@FeignClient(value = "demo-user")
@RequestMapping("/v1/auth")
public interface AuthResource {
    @PostMapping("/authenticate")
    GenericResultDto<AuthorizeResponseDTO> authorize(@RequestBody LoginVM loginVm);

    @PostMapping("/register")
    ResultDto registerAccount(@RequestBody ManagedUserDTO managedUserVm);

    @GetMapping("/authenticate")
    ResultDto isAuthenticated(HttpServletRequest request);

}
