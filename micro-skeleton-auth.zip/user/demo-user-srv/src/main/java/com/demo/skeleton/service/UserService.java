package com.demo.skeleton.service;

import com.demo.skeleton.api.dto.ManagedUserDTO;
import com.demo.skeleton.api.dto.response.AuthorizeResponseDTO;
import com.demo.skeleton.exception.AppBizException;
import com.demo.skeleton.model.domain.User;

import javax.validation.Valid;

public interface UserService {
    /**
     * 用户注册
     **/
    User registerUser(@Valid ManagedUserDTO managedUserVm, String password) throws AppBizException;

    /**
     * 根据用户名，密码登录认证
     **/
    AuthorizeResponseDTO authorize(String login, String password) throws AppBizException;

    AuthorizeResponseDTO authorize(User user) throws AppBizException;

}
