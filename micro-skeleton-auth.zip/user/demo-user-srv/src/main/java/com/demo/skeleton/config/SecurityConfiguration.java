package com.demo.skeleton.config;

import com.demo.skeleton.utils.AESUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.regex.Pattern;

@Configuration
public class SecurityConfiguration {

    private Pattern BCRYPT_PATTERN = Pattern.compile("\\A\\$2a?\\$\\d\\d\\$[./0-9A-Za-z]{53}");

    @Bean
    public PasswordEncoder passwordEncoder() {

        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

        return new  PasswordEncoder() {
            @Override
            public String encode(CharSequence rawPassword) {
                return AESUtils.encrypt(rawPassword.toString());
            }

            @Override
            public boolean matches(CharSequence rawPassword, String encodedPassword) {
                //老加密密码
                if (BCRYPT_PATTERN.matcher(encodedPassword).matches()) {
                    return bCryptPasswordEncoder.matches(rawPassword, encodedPassword);
                }
                if (encodedPassword == null || encodedPassword.length() == 0) {
                    return false;
                }
                return encodedPassword.equals(encode(rawPassword));
            }
        };
    }



}
