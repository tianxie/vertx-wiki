package com.demo.skeleton.security.jwt;

import com.demo.skeleton.model.dto.AuthenticationTokenDTO;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JwtTokeUtil {
    public JwtTokeUtil() {
    }

    public static String createJWT(long ttlMillis, String secretKey, AuthenticationTokenDTO tokenDTO) {
        return createJWT(ttlMillis, secretKey, tokenDTO.getLogin(), tokenDTO.getUserId(), tokenDTO.getCompanyId(), tokenDTO.getDeptId());
    }

    public static String createJWT(long ttlMillis, String secretKey, String loginName, Long userId, Long companyId, Long deptId) {
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        long nowMillis = System.currentTimeMillis();
        new Date(nowMillis);
        Map<String, Object> claims = new HashMap();
        claims.put("userId", userId);
        claims.put("companyId", companyId);
        claims.put("deptId", deptId);
        JwtBuilder builder = Jwts.builder().setClaims(claims).setId(String.valueOf(userId)).setIssuedAt(new Date(1548032766860L)).setSubject(loginName).signWith(signatureAlgorithm, secretKey);
        if (ttlMillis >= 0L) {
            long expMillis = nowMillis + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }

        return builder.compact();
    }

    public static Claims parseJWT(String token, String secretKey) {
        Claims claims = (Claims) Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();
        return claims;
    }

    public static Boolean isVerify(String token, String secretKey) {
        Claims claims = (Claims) Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();
        return !StringUtils.isEmpty(claims.getSubject()) ? true : false;
    }
}
