package com.demo.skeleton.exception;

import com.demo.skeleton.api.constants.AppExcCodesEnum;
import lombok.Data;

import java.util.LinkedHashMap;
import java.util.Map;
@Data
public class AppBizException extends Exception {
    private static final long serialVersionUID = 7366300105025102661L;

    /**
     * 异常代码
     */
    private String code;

    /**
     * 本地化异常信息
     */
    private String localizedMessage;

    /**
     * 异常信息是否不可修改
     */
    private boolean immutable = false;

    /**
     * 是否已输出异常信息
     */
    private boolean logged = false;

    /**
     * 异常数据上下文对象数组
     */
    private Map<String, String> context = new LinkedHashMap<String, String>();

    public AppBizException(String code) {
        this.code = code;
    }

    public AppBizException(String code, String message) {
        super(message);
        this.code = code;
        this.localizedMessage = message;
    }

    public AppBizException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
        this.localizedMessage = message;
    }

    public AppBizException(String code, Throwable t) {
        super(t);
        this.code = code;
    }

    public AppBizException(String code, String message, Map<String, String> params) {
        super(message);
        this.code = code;
        this.localizedMessage = message;
        context.putAll(params);
    }

    public AppBizException(AppExcCodesEnum appBizExcCodes) {
        super(appBizExcCodes.getMessage());
        this.code = appBizExcCodes.getCode();
        this.localizedMessage = appBizExcCodes.getMessage();
    }
}
