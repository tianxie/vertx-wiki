package com.demo.skeleton.exception;

import java.text.MessageFormat;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 */
public class AppBizRuntimeException extends RuntimeException{
    private String code;
    private String localizedMessage;
    private boolean immutable = false;
    private boolean logged = false;
    private Map<String, String> context = new LinkedHashMap();

    public AppBizRuntimeException(String code) {
        this.code = code;
    }

    public AppBizRuntimeException(String code, String message) {
        super(message);
        this.code = code;
        this.localizedMessage = message;
    }

    public AppBizRuntimeException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
        this.localizedMessage = message;
    }

    public AppBizRuntimeException(String code, Throwable t) {
        super(t);
        this.code = code;
    }

    public AppBizRuntimeException(String code, String message, Map<String, String> params) {
        super(message);
        this.code = code;
        this.localizedMessage = message;
        this.context.putAll(params);
    }

    public AppBizRuntimeException(String code, String message, Map<String, String> params, Throwable cause) {
        super(message, cause);
        this.code = code;
        this.localizedMessage = message;
        this.context.putAll(params);
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setLocalizedMessage(String localizedMessage) {
        this.localizedMessage = localizedMessage;
    }

    @Override
    public String getLocalizedMessage() {
        return this.localizedMessage;
    }

    public Map<String, String> getContext() {
        return this.context;
    }

    public void setContext(Map<String, String> args) {
        this.context = args;
    }

    public boolean isImmutable() {
        return this.immutable;
    }

    public void setImmutable(boolean immutable) {
        this.immutable = immutable;
    }

    public boolean isLogged() {
        return this.logged;
    }

    public void setLogged(boolean logged) {
        this.logged = logged;
    }

    @Override
    public String toString() {
        String s = this.getClass().getName() + ", code=" + this.code;
        String message = this.getLocalizedMessage();
        return message != null ? s + ": " + message : s;
    }
}
