package com.demo.skeleton.web;

import com.demo.skeleton.api.AuthResource;
import com.demo.skeleton.api.constants.AppExcCodesEnum;
import com.demo.skeleton.api.dto.GenericResultDto;
import com.demo.skeleton.api.dto.ManagedUserDTO;
import com.demo.skeleton.api.dto.ResultDto;
import com.demo.skeleton.api.dto.request.LoginVM;
import com.demo.skeleton.api.dto.response.AuthorizeResponseDTO;
import com.demo.skeleton.exception.AppBizException;
import com.demo.skeleton.model.domain.User;
import com.demo.skeleton.service.UserService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 注册，登录等白名单用户功能
 */
@RestController
public class AuthResourceImpl implements AuthResource {

    @Autowired
    private UserService userService;

    /**
     * 使用用户名和密码登录
     *
     * @param loginVm
     * @return
     */
    @Override
    public GenericResultDto<AuthorizeResponseDTO> authorize(@RequestBody LoginVM loginVm) {
        GenericResultDto<AuthorizeResponseDTO> response;
        try {
            AuthorizeResponseDTO result = userService.authorize(loginVm.getUsername(), loginVm.getPassword());
            response = GenericResultDto.ok(result);
        } catch (AppBizException e) {
            response = GenericResultDto.fail(e.getCode(), e.getMessage());
        }
        return response;
    }

    /**
     * 注册并登录
     *
     * @param managedUserVm
     * @return
     */
    @Override
    public ResultDto registerAccount(@RequestBody ManagedUserDTO managedUserVm) {
        ResultDto response;
        if (!checkPasswordLength(managedUserVm.getPassword())) {
            response = ResultDto.fail("" + AppExcCodesEnum.OPERATE_FAIL, "password length is invalid");
            return response;
        }

        //用户注册
        try {
            User user = userService.registerUser(managedUserVm, managedUserVm.getPassword());
            AuthorizeResponseDTO dto = userService.authorize(user);
            response = ResultDto.ok(dto);
        } catch (AppBizException e) {
            response = ResultDto.fail(e.getCode(), e.getMessage());
        }
        return response;
    }

    /**
     * 是否已认证
     *
     * @param request
     * @return
     */
    @Override
    public ResultDto isAuthenticated(HttpServletRequest request) {
        return null;
    }

    private static boolean checkPasswordLength(String password) {
        return !StringUtils.isEmpty(password) &&
                password.length() >= ManagedUserDTO.PASSWORD_MIN_LENGTH &&
                password.length() <= ManagedUserDTO.PASSWORD_MAX_LENGTH;
    }
}
