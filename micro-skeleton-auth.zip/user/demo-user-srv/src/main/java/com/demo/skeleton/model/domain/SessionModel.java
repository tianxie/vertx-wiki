package com.demo.skeleton.model.domain;

import lombok.Data;

@Data
public class SessionModel {
    private long userId;
    private long companyId;
    private long deptId;
}
