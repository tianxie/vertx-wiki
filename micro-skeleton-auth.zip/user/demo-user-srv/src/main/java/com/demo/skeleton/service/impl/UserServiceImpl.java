package com.demo.skeleton.service.impl;

import com.demo.skeleton.api.constants.AppExcCodesEnum;
import com.demo.skeleton.api.dto.ManagedUserDTO;
import com.demo.skeleton.api.dto.response.AuthorizeResponseDTO;
import com.demo.skeleton.exception.AppBizException;
import com.demo.skeleton.mapper.UserMapper;
import com.demo.skeleton.model.domain.User;
import com.demo.skeleton.model.dto.AuthenticationTokenDTO;
import com.demo.skeleton.security.jwt.TokenProvider;
import com.demo.skeleton.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisStringCommands;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.types.Expiration;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 个人账户管理
 * 主要提供下面服务：
 * 用户注册
 * 用户登录登出
 * 用户修改密码
 *
 * @author 00751413
 */
@Service
public class UserServiceImpl implements UserService {
    private static final Logger LOG = LoggerFactory.getLogger(UserServiceImpl.class);

    private Long redisTokenExpiredTime = 3600L;
    private static final long TIME_BASE = 1000L;

    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private TokenProvider tokenProvider;
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    StringRedisTemplate stringRedisTemplate;
    @Autowired
    private HttpServletRequest request;


    private Pattern BCRYPT_PATTERN = Pattern.compile("\\A\\$2a?\\$\\d\\d\\$[./0-9A-Za-z]{53}");
    private final static String REGEX = "^\\w+$";

    @Override
    @Transactional(rollbackFor = Exception.class)
    public User registerUser(@Valid ManagedUserDTO userDto, String password) throws AppBizException {
        if (userMapper.checkLoginExists(userDto.getLogin())) {
            throw new AppBizException(AppExcCodesEnum.OPERATE_FAIL);
        }

        User newUser = new User();
        String encryptedPassword = passwordEncoder.encode(password);
        newUser.setLogin(userDto.getLogin());
        newUser.setPassword(encryptedPassword);
        newUser.setStatus("1");
        newUser.setName(userDto.getName());
        newUser.setEmail(userDto.getEmail());
        newUser.setTelNumber(userDto.getTelNumber());
        newUser.setImageUrl(userDto.getImageUrl());
        newUser.setLangKey(userDto.getLangKey());
        newUser.setCreateBy("9999999999");
        newUser.setCreateTime(new Date());
        newUser.setUpdateTime(new Date());
        newUser.setUpdateBy("9999999999");
        newUser.setFirstLogin(true);
        newUser.setInitPassword(encryptedPassword);
        userMapper.insert(newUser);

        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(newUser.getLogin(), newUser.getPassword());
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
        return newUser;
    }

    @Override
    public AuthorizeResponseDTO authorize(String login, String password) throws AppBizException {
        User user;
        user = this.userMapper.selectByLogin(login);
        if (null == user) {
            try {
                Long telNumber = Long.parseLong(login);
                user = this.userMapper.selectByTelNumber(telNumber);
            } catch (Exception ex) {
                LOG.info("login is {}", login);
            }
        }

        if (null == user) {
            throw new AppBizException(AppExcCodesEnum.OPERATE_FAIL);
        }

        //密码验证
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new AppBizException(AppExcCodesEnum.PASSWORD_NOT_MATCH);
        }

        Boolean initPwd = passwordEncoder.matches(password, user.getInitPassword());
        AuthorizeResponseDTO result = this.authorize(user, initPwd);
        return result;
    }

    /**
     * 生成token
     */
    private String createAuthAndSaveToRedis(String login, Long userId, Long companyId, Long deptId) {
        AuthenticationTokenDTO tokenDTO = new AuthenticationTokenDTO();
        tokenDTO.setLogin(login);
        tokenDTO.setUserId(userId);
        tokenDTO.setCompanyId(companyId);
        tokenDTO.setDeptId(deptId);
        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(login, tokenDTO);
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
        //删除之前登录的用户token信息
        this.removeTokenInRedis(tokenDTO);
        String jwt = tokenProvider.createToken(tokenDTO);
        redisTemplate.execute((RedisCallback<Boolean>) connection -> {
            RedisSerializer serializer = redisTemplate.getStringSerializer();
            connection.set(Objects.requireNonNull(serializer.serialize(jwt)), Objects.requireNonNull(serializer.serialize(jwt)), Expiration.seconds(redisTokenExpiredTime), RedisStringCommands.SetOption.UPSERT);
            return true;
        });
        return jwt;
    }

    @Override
    public AuthorizeResponseDTO authorize(User user) throws AppBizException {
        return this.authorize(user, true);
    }

    private AuthorizeResponseDTO authorize(User user, Boolean initPwd) throws AppBizException {
        String jwt = createAuthAndSaveToRedis(user.getLogin(), user.getId(), 1L, 2L);
        // 初次登录处理
        Boolean firstLogin = user.getFirstLogin();
        AuthorizeResponseDTO result = new AuthorizeResponseDTO();
        result.setIdToken(jwt);
        result.setFirstLogin(firstLogin);
        result.setInitPwd(initPwd);
        Set<Long> companies = new HashSet<>();
        companies.add(1L);
        result.setCompanies(companies);
        return result;
    }

    /**
     * 从redis中移除用户Token
     *
     * @param user 用户
     */
    private void removeTokenInRedis(AuthenticationTokenDTO user) {
        String prefix = tokenProvider.getRedisPrefixKey(user);
        Set<String> keys = stringRedisTemplate.keys(prefix + "*");
        if (!CollectionUtils.isEmpty(keys)) {
            for (String key : keys) {
                LOG.debug(String.format("key is %s ", key));
                stringRedisTemplate.delete(key);
            }
        }
    }

}
