package com.demo.skeleton.security.jwt;

import com.demo.skeleton.model.dto.AuthenticationTokenDTO;
import io.jsonwebtoken.Claims;

import java.util.UUID;

public final class JwtUtil {
    static String PREFIX = "<TK>";
    static String SUFFIX = "</TK>";

    public JwtUtil() {
    }

    public static String createJWT(long ttlMillis, String loginName, Long userId, String secretKey, Long companyId) {
        String jwtToken = JwtTokeUtil.createJWT(-1L, secretKey, loginName, userId, companyId, (Long) null);
        StringBuilder token = new StringBuilder();
        token.append(PREFIX).append(jwtToken).append(SUFFIX).append(UUID.randomUUID().toString());
        return token.toString();
    }

    public static String createJWT(long ttlMillis, String secretKey, AuthenticationTokenDTO tokenDTO) {
        String jwtToken = JwtTokeUtil.createJWT(-1L, secretKey, tokenDTO);
        StringBuilder token = new StringBuilder();
        token.append(PREFIX).append(jwtToken).append(SUFFIX).append(UUID.randomUUID().toString());
        return token.toString();
    }

    public static String createJWTWithoutUUID(String secretKey, AuthenticationTokenDTO tokenDTO) {
        String jwtToken = JwtTokeUtil.createJWT(-1L, secretKey, tokenDTO);
        StringBuilder token = new StringBuilder();
        token.append(PREFIX).append(jwtToken).append(SUFFIX);
        return token.toString();
    }

    public static Claims parseJWT(String token, String secretKey) {
        int pos = token.indexOf(SUFFIX);
        String jwtToken = token.substring(4, pos);
        return JwtTokeUtil.parseJWT(jwtToken, secretKey);
    }

    public static String createJWTWithoutUUID(String loginName, Long userId, String secretKey, Long companyId) {
        String jwtToken = JwtTokeUtil.createJWT(-1L, secretKey, loginName, userId, companyId, (Long) null);
        StringBuilder token = new StringBuilder();
        token.append(PREFIX).append(jwtToken).append(SUFFIX);
        return token.toString();
    }

    public static Boolean isVerify(String token, String secretKey) {
        int pos = token.indexOf(SUFFIX);
        String jwtToken = token.substring(4, pos);
        return JwtTokeUtil.isVerify(jwtToken, secretKey);
    }
}
