package com.demo.skeleton.mapper;

import com.demo.skeleton.model.domain.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {
    int deleteByPrimaryKey(Long id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Long id);

    String selectImageByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

    int updateByPrimaryKeyWithBlobs(User record);

    boolean checkLoginExists(String login);

    boolean checkTelNumberExists(Long telNumber);

    boolean checkEmailExists(String email);

    User selectByLogin(String login);

    int updatePasswordByTelNumber(User record);

    User selectByTelNumber(Long telNumber);

    int updatePasswordByLogin(User record);

    List<User> selectList(Map<String, Object> map);

    List<User> selectByIds(List<Long> userIds);

}