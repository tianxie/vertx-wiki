package com.demo.skeleton.security.jwt;

import com.demo.skeleton.model.dto.AuthenticationTokenDTO;
import io.jsonwebtoken.Claims;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class TokenProvider {

    private final Logger log = LoggerFactory.getLogger(TokenProvider.class);

    private static final String AUTHORITIES_KEY = "auth";

    private String secretKey;

    private long tokenValidityInMilliseconds;

    @PostConstruct
    public void init() {
        this.secretKey = "webapp";
        this.tokenValidityInMilliseconds = 1000 * 60 * 60 * 24 * 365 * 100;
    }

    public Authentication getAuthenticationFromClaims(Claims claims) {
        String login = claims.getSubject();
        Long userId = claims.get("userId", Long.class);
        Long companyId = claims.get("companyId", Long.class);
        Long deptId = claims.get("deptId", Long.class);
        AuthenticationTokenDTO token = new AuthenticationTokenDTO();
        token.setLogin(login);
        token.setUserId(userId);
        token.setCompanyId(companyId);
        token.setDeptId(deptId);
        return new UsernamePasswordAuthenticationToken(login, token);
    }

    public String createToken(AuthenticationTokenDTO tokenDTO) {
        return JwtUtil.createJWT(tokenValidityInMilliseconds, secretKey, tokenDTO);
    }

    public String getRedisPrefixKey(AuthenticationTokenDTO tokenDTO) {
        return JwtUtil.createJWTWithoutUUID(secretKey, tokenDTO);
    }

    public Claims getAuthentication(String token) {
        return JwtUtil.parseJWT(token, secretKey);
    }

    public boolean validateToken(String authToken) {
        return JwtUtil.isVerify(authToken, secretKey);
    }
}
