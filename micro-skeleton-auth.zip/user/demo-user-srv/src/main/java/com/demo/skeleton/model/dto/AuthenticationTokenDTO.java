package com.demo.skeleton.model.dto;

import lombok.Data;

@Data
public class AuthenticationTokenDTO {
    String login;
    Long userId;
    Long companyId;
    Long deptId;
}
