package com.demo.skeleton.utils;

import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.SecureRandom;
import java.util.UUID;

/**
 * AES 对称算法加密/解密工具类
 *
 */
@Slf4j
public class AESUtils {

    /** 密钥长度: 128, 192 or 256 */
    private static final int KEY_SIZE = 128;

    /** 加密/解密算法名称 */
    private static final String ALGORITHM = "AES";

    /** 随机数生成器（RNG）算法名称 */
    private static final String RNG_ALGORITHM = "SHA1PRNG";

    private static final String KEY ="%5$#@。";


    /**
     * 生成密钥对象
     */
    private static SecretKey generateKey(byte[] key) throws Exception {
        // 创建安全随机数生成器
        SecureRandom random = SecureRandom.getInstance(RNG_ALGORITHM);
        // 设置 密钥key的字节数组 作为安全随机数生成器的种子
        random.setSeed(key);

        // 创建 AES算法生成器
        KeyGenerator gen = KeyGenerator.getInstance(ALGORITHM);
        // 初始化算法生成器
        gen.init(KEY_SIZE, random);

        // 生成 AES密钥对象, 也可以直接创建密钥对象: return new SecretKeySpec(key, ALGORITHM);
        return gen.generateKey();
    }

    /**
     * 数据加密: 明文 -> 密文
     */
    public static byte[] encrypt(byte[] plainBytes, byte[] key) throws Exception {
        // 生成密钥对象
        SecretKey secKey = generateKey(key);

        // 获取 AES 密码器
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        // 初始化密码器（加密模型）
        cipher.init(Cipher.ENCRYPT_MODE, secKey);

        // 加密数据, 返回密文
        byte[] cipherBytes = cipher.doFinal(plainBytes);

        return cipherBytes;
    }
    /**
     * 数据加密: 明文 -> 密文
     */
    public static String encrypt(String str) {

        if(str == null || str.length() == 0) {
            return null;
        }

        byte[] plainBytes = str.getBytes();
        // 生成密钥对象
        String encodeString = null;
        try {
            SecretKey secKey = generateKey(KEY.getBytes());
            // 获取 AES 密码器
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            // 初始化密码器（加密模型）
            cipher.init(Cipher.ENCRYPT_MODE, secKey);
            // 加密数据, 返回密文
            byte[] cipherBytes = cipher.doFinal(plainBytes);
            encodeString =  bytesToHexString(cipherBytes);
        } catch (Exception e) {
            log.error("Exception", e);
        }

        return encodeString;
    }

    /**
     * 数据解密: 密文 -> 明文
     */
    public static byte[] decrypt(byte[] cipherBytes, byte[] key) throws Exception {
        // 生成密钥对象
        SecretKey secKey = generateKey(key);

        // 获取 AES 密码器
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        // 初始化密码器（解密模型）
        cipher.init(Cipher.DECRYPT_MODE, secKey);

        // 解密数据, 返回明文
        byte[] plainBytes = cipher.doFinal(cipherBytes);

        return plainBytes;
    }
    /**
     * 数据解密: 密文 -> 明文
     */
    public static String decrypt(String str)  {

        if(str == null || str.length() == 0) {
            return null;
        }
        // 生成密钥对象
        String decodeString = null;
        try {
            byte[] cipherBytes = hexStringTobytes(str);
            SecretKey secKey = generateKey(KEY.getBytes());
            // 获取 AES 密码器
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            // 初始化密码器（解密模型）
            cipher.init(Cipher.DECRYPT_MODE, secKey);
            byte[] plainBytes = cipher.doFinal(cipherBytes);
            decodeString = new String(plainBytes);
        } catch (Exception e) {
            log.error("Exception", e);
        }
        // 解密数据, 返回明文

        return decodeString;
    }

    public static String bytesToHexString(byte[] bArr) {
        StringBuffer sb = new StringBuffer(bArr.length);
        String sTmp;

        for (int i = 0; i < bArr.length; i++) {
            sTmp = Integer.toHexString(0xFF & bArr[i]);
            if (sTmp.length() < 2)
                sb.append(0);
            sb.append(sTmp.toUpperCase());
        }

        return sb.toString();
    }
    /*
     * 十六进制转byte[]数组
     */
    public static byte[] hexStringTobytes(String hexStr) {
        if(hexStr == null || hexStr.length() == 0) {
            return null;
        }
        if(hexStr.length()%2 != 0) {//长度为单数
            hexStr = "0" + hexStr;//前面补0
        }
        char[] chars = hexStr.toCharArray();
        int len = chars.length/2;
        byte[] bytes = new byte[len];
        for (int i = 0; i < len; i++) {
            int x = i*2;
            bytes[i] = (byte)Integer.parseInt(String.valueOf(new char[]{chars[x], chars[x+1]}), 16);
        }
        return bytes;
    }


    public static void main(String[] args)  {
        String  data = UUID.randomUUID().toString().replaceAll("-","").substring(0,15);
        byte[] desKey = KEY.getBytes();
        String desResult = encrypt(data);
        System.out.println(data + ">>>DES 加密结果>>>" + desResult.length()+desResult);

    }

}
